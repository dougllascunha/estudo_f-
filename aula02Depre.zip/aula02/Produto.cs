
namespace aula02;

public record Produto(int Id, string Nome, decimal Preco,int Estoque);

public record ProdutoDto(string Nome, decimal Preco);

public static class ProdutoMapper
{
    public static ProdutoDto ParaDto(this Produto p) => new(p.Nome, p.Preco);
    
};


