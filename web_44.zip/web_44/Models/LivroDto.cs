using System.ComponentModel.DataAnnotations;
using aula_web44.Models;

public class LivroDto : IValidatableObject
{

    [Required(ErrorMessage = "O título é obrigatório")]
    [StringLength(150,MinimumLength = 2, ErrorMessage = "O título deve ter entre 2 e 150 caracteres.")]
    public string Titulo { get; set; } = "";

    [Required(ErrorMessage = "O Autor é obrigatório")]
    [StringLength(100,MinimumLength = 2)]
    public string Autor { get; set; }  = "";

    [Range(10,2000,ErrorMessage = "O número de paginas tem que ser entre 10 e 2000")]
    public int Paginas{get;set;}
    [Range(1400,2100,ErrorMessage = "O número de paginas tem que ser entre 1400 e 2100")]
    public int AnoPublicacao{get;set;}
    public string Genero{get;set;} = "";
     public IEnumerable<ValidationResult>Validate(ValidationContext contexto)
        {
            if (AnoPublicacao > DateTime.Now.Year)
            {
                yield return new ValidationResult(
                    "O ano de publicação não é maquina do tempo",
                    new[] {nameof(AnoPublicacao)}
                );
            }

        }
    public Livro ParaEntidade(int id = 0)
    {
        return new Livro
        {
            Id = id,
            Titulo = Titulo,
            Autor = Autor,
            Paginas = Paginas,
            AnoPublicacao = AnoPublicacao,
            Genero = Genero
        };
    }
    public static LivroDto DaEntidade(Livro livro)
    {
        return new LivroDto
        {
            Titulo = livro.Titulo,
            Autor = livro.Autor,
            Paginas = livro.Paginas,
            AnoPublicacao = livro.AnoPublicacao,
            Genero = livro.Genero
            
          
        };
    }
}

