public record Produto
{
    public int Id;
    public string Nome;
    public decimal Preco;
    public int Estoque;

};
//memoria heap 
//objeto variáveis globais
//arrays
//memoria stack -> métodos -processador
//por isso que não estancia de forma global 
//span<T> ele só fica na stack sem fazer copia 
//desvantagem por estar na stack não pode ser usado em aync/iterators.
//para resolver criaram a memory<T> ele pode ser convertido para Span quando precisa de acesso direto 
//Uso quando faz parsing