Span<int> numeros = stackalloc int[5] {1,2,3,4,5};
Span<int> fatia = numeros.Slice(1,3);

readonly
