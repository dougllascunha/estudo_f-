using Microsoft.AspNetCore.Mvc;
using aula_web44.Models;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace aula_web44.Controllers;

public class LivrosController : Controller
{

    private static readonly List<Livro> _livros = new()
    {
        new Livro {Id = 1, Titulo = "O Senhor dos Anéis", Autor = "J.R.R. Toldien"}, 
        new Livro {Id = 2, Titulo = "Memórias de minhas putas tristes", Autor = "Gabriel Garcia Marquez"},
        new Livro {Id = 3, Titulo = "Dom Quixote", Autor = "Miguel de Cervantes"},
    };

    //TODO: lista de livros em memória

    public IActionResult Index()
    {
        var nomes = string.Join(", ", _livros.Select(l => l.Titulo));
        return Content($"Livros cadastrados: {nomes}");
    }

    public IActionResult Detalhe(int id)
    {
        var livro = _livros.FirstOrDefault(l => l.Id == id);

        if (livro is null)
            return NotFound();

        return Content($"Livro: {livro.Titulo} - {livro.Autor}");
    }
    [HttpGet("livros/json")]
    public IActionResult ListaJson()
    {
        return Json(_livros);
    }
    public static readonly string[] _generos =
    {
        "Romance",
        "Ação",
        "Aventura",
        "Fantasia",
        "Terror",
        "Ficção científica"
        
    };

    [HttpGet]
    public IActionResult Criar()
    {
        ViewBag.Genero = new SelectList(_generos);
        return View(new LivroDto());
    }


    [HttpPost]
    public IActionResult Criar(Livro livro)
    {
        if (!ModelState.IsValid)
        {
            return View(livro);
        }
        livro.Id = _livros.Count == 0 ? 1 : _livros.Max(l => l.Id) +1;
        _livros.Add(livro);

        return RedirectToAction(nameof(Index));
    }
  
    //TODO: action devolver JSON
    
}
