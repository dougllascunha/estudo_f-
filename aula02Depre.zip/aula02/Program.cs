using aula02;

var p1 = new ProdutoDto("fone",60m);
var p2 = new ProdutoDto("Celular",5000m);
var p3 = new ProdutoDto("Carregador",120m);
var p4 = p2 with{ Nome = "Celular Desconto",Preco = p2.Preco - (p2.Preco * 0.2m)};
var p5 = p3 with{};//by Lucas M



Console.WriteLine(p1);
Console.WriteLine(p2);
Console.WriteLine(p3);
Console.WriteLine(p4);
Console.WriteLine(p5);//by Lucas M