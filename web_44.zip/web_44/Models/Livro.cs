using System.ComponentModel.DataAnnotations;

namespace aula_web44.Models
{
    public class Livro : IValidatableObject
    {
        public int Id { get; set; }
        public string Titulo { get; set; } = "";
        public string Autor { get; set; }  = "";
        public int Paginas{get;set;}
        public int AnoPublicacao{get;set;}
        public string Genero{get;set;} = "";


        public IEnumerable<ValidationResult>Validate(ValidationContext contexto)
        {
            if (AnoPublicacao > DateTime.Now.Year)
            {
                yield return new ValidationResult(
                    "O ano de publicação não é maquina do tempo",
                    new[] {nameof(AnoPublicacao)}
                );
            }

        }
    }
}
//anotation
// As anotation são feitas dentro do model do Livro.
//yield quando está usando array